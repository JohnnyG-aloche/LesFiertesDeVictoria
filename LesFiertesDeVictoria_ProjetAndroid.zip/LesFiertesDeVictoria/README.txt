LES FIERTÉS DE VICTORIA — projet Android

Fonctions :
- Compteur de diamants (+1 / -1)
- Compteur 💩 (+1 / -1)
- Sauvegarde automatique locale (SharedPreferences)
- Fonctionne hors connexion
- Android 6.0 ou supérieur (API 23+)

Créer l'APK :
1. Installer Android Studio.
2. Ouvrir le dossier LesFiertesDeVictoria dans Android Studio.
3. Laisser Gradle se synchroniser (Android SDK Platform 35 requis).
4. Menu Build > Build Bundle(s) / APK(s) > Build APK(s).
5. L'APK debug sera généré dans app/build/outputs/apk/debug/app-debug.apk.

Pour installer sur le téléphone :
- Transférer app-debug.apk sur le téléphone Android.
- Ouvrir le fichier et autoriser l'installation depuis cette source si Android le demande.

Remarque : ce dossier contient le projet source Android. Il ne contient pas encore un APK compilé.
