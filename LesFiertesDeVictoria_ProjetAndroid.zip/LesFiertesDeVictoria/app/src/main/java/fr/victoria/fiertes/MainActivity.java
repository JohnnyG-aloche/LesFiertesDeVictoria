package fr.victoria.fiertes;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.content.SharedPreferences;

public class MainActivity extends Activity {
    private SharedPreferences prefs;
    private TextView diamondsValue, poopValue;
    private int diamonds, poop;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("victoria_stock", MODE_PRIVATE);
        diamonds = prefs.getInt("diamonds", 0);
        poop = prefs.getInt("poop", 0);
        buildScreen();
    }

    private int dp(float value) {
        return (int)(value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setGravity(Gravity.CENTER);
        return t;
    }

    private Button button(String label, int color) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(20);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(color));
        return b;
    }

    private LinearLayout.LayoutParams params(int width, int height) {
        return new LinearLayout.LayoutParams(width < 0 ? width : dp(width), height < 0 ? height : dp(height));
    }

    private void buildScreen() {
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setGravity(Gravity.CENTER_HORIZONTAL);
        page.setPadding(dp(22), dp(26), dp(22), dp(24));
        page.setBackgroundColor(Color.rgb(245, 247, 252));

        TextView title = text("🏆 Les fiertés de Victoria", 25, Color.rgb(38, 48, 85), true);
        page.addView(title, params(-1, 72));

        TextView subtitle = text("Le petit inventaire Minecraft", 15, Color.rgb(95, 101, 120), false);
        page.addView(subtitle, params(-1, 36));

        diamondsValue = addCounter(page, "💎", "Diamants", true);
        poopValue = addCounter(page, "💩", "Cacas", false);

        TextView note = text("Les quantités sont sauvegardées automatiquement sur ce téléphone.", 12,
                Color.rgb(110, 115, 130), false);
        LinearLayout.LayoutParams noteParams = params(-1, -2);
        noteParams.topMargin = dp(18);
        page.addView(note, noteParams);

        setContentView(page);
        refresh();
    }

    private TextView addCounter(LinearLayout page, String emoji, String label, boolean isDiamond) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER);
        card.setPadding(dp(16), dp(14), dp(16), dp(14));
        card.setBackgroundColor(Color.WHITE);
        card.setElevation(dp(3));
        LinearLayout.LayoutParams cardParams = params(-1, 0);
        cardParams.weight = 1;
        cardParams.topMargin = dp(14);
        page.addView(card, cardParams);

        TextView heading = text(emoji + "  " + label, 23, Color.rgb(45, 51, 70), true);
        card.addView(heading, params(-1, 48));

        TextView count = text("0", 48, Color.rgb(35, 45, 80), true);
        card.addView(count, params(-1, 78));

        LinearLayout actions = new LinearLayout(this);
        actions.setGravity(Gravity.CENTER);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        card.addView(actions, params(-1, 60));

        Button minus = button("− 1", Color.rgb(220, 75, 85));
        Button plus = button("+ 1", Color.rgb(45, 155, 105));
        LinearLayout.LayoutParams actionParams = new LinearLayout.LayoutParams(0, dp(54), 1);
        actionParams.setMargins(dp(6), 0, dp(6), 0);
        actions.addView(minus, actionParams);
        actions.addView(plus, actionParams);

        minus.setOnClickListener(v -> {
            if (isDiamond) diamonds = Math.max(0, diamonds - 1);
            else poop = Math.max(0, poop - 1);
            saveAndRefresh();
        });
        plus.setOnClickListener(v -> {
            if (isDiamond) diamonds++;
            else poop++;
            saveAndRefresh();
        });
        return count;
    }

    private void saveAndRefresh() {
        prefs.edit().putInt("diamonds", diamonds).putInt("poop", poop).apply();
        refresh();
    }

    private void refresh() {
        diamondsValue.setText(String.valueOf(diamonds));
        poopValue.setText(String.valueOf(poop));
    }
}
